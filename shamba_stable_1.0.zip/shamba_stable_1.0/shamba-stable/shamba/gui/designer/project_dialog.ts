<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="fr">
<context>
    <name>project</name>
    <message>
        <location filename="project_dialog_ui.py" line="1803"/>
        <source>Project Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1804"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:18pt; font-weight:600;&quot;&gt;NEW BASELINE OR INTERVENTION&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1809"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:14pt;&quot;&gt;The following screens will prompt you to enter information &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:14pt;&quot;&gt;about the farming activities that make up an &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:14pt;&quot;&gt;intervention or baseline&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1816"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:14pt; font-weight:600;&quot;&gt;OVERVIEW&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1821"/>
        <source>Is soil management included?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1975"/>
        <source>Yes</source>
        <translation>Oui</translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1976"/>
        <source>No</source>
        <translation>Non</translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1824"/>
        <source>Are you planting, or changing the 
management of, crops or other
annuals?   </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1829"/>
        <source>Are you planting, or changing the 
management of, trees or other
perennials?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1834"/>
        <source>Are you adding any external organic
inputs or synthetic fertiliser?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1836"/>
        <source>How many crop species
are being planted?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1838"/>
        <source>How many tree species
are being planted?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1842"/>
        <source>How many kinds of external organic
inputs or fertiliser are being added?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1844"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:14pt; font-weight:600;&quot;&gt;Soil Data&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1849"/>
        <source>How would you like
to enter soil data?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1851"/>
        <source>Use HWSD data for this
location (recommended)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1853"/>
        <source>Load data from an existing file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="2019"/>
        <source>Enter custom data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1855"/>
        <source>Soil types to be modelled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1862"/>
        <source>To come in v2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1863"/>
        <source>type 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1864"/>
        <source>soily</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1865"/>
        <source>Select a file to load</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="2021"/>
        <source>Browse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1867"/>
        <source>Soil organic carbon at start of project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1868"/>
        <source>tonnes carbon per hectare</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1869"/>
        <source>Soil clay content at start of project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="2008"/>
        <source>%</source>
        <translation></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1871"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:14pt; font-weight:600;&quot;&gt;Soil and Fire Management&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1876"/>
        <source>When is the soil covered?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1877"/>
        <source>All months</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1878"/>
        <source>Some months</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="2067"/>
        <source>Never</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1880"/>
        <source>Check the months when
soil is covered:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1882"/>
        <source>January</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1883"/>
        <source>February</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1884"/>
        <source>March</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1885"/>
        <source>April</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1886"/>
        <source>May</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1887"/>
        <source>June</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1888"/>
        <source>July</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1889"/>
        <source>August</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1890"/>
        <source>September</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1891"/>
        <source>October</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1892"/>
        <source>November</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1893"/>
        <source>December</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1894"/>
        <source>How often is there a fire?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="2068"/>
        <source>Every</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="2069"/>
        <source>years</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="2070"/>
        <source>Other </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1899"/>
        <source>Please enter a list and/or range
of years in which fire occurs
(e.g. 2,7-9,18):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1902"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:14pt; font-weight:600;&quot;&gt;Crop Management&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1907"/>
        <source>Crop planted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="2023"/>
        <source>--Select--</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1909"/>
        <source>--Specific species--</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1910"/>
        <source>maize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1911"/>
        <source>wheat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1912"/>
        <source>winter wheat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1913"/>
        <source>spring wheat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1914"/>
        <source>rice</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1915"/>
        <source>barley</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1916"/>
        <source>oats</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1917"/>
        <source>millet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1918"/>
        <source>sorghum</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1919"/>
        <source>rye</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1920"/>
        <source>soyabean</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1921"/>
        <source>dry bean</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1922"/>
        <source>potato</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1923"/>
        <source>peanut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1924"/>
        <source>alfalfa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1925"/>
        <source>non-legume hay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1959"/>
        <source>--Generic types--</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1927"/>
        <source>grains</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1928"/>
        <source>beans and pulses</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1929"/>
        <source>tubers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1930"/>
        <source>root crops</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1931"/>
        <source>N-fixing forages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1932"/>
        <source>non N-fixing forages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1933"/>
        <source>perennial grasses</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1934"/>
        <source>grass-clover mixtures</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="2033"/>
        <source>--Advanced (available in v2)--</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1936"/>
        <source>Other crop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1937"/>
        <source>How to enter advanced crop
data (to come in v2)?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="2018"/>
        <source>Load from existing file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="2020"/>
        <source>Select a file to  load:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1943"/>
        <source>Annual dry crop yield</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="2051"/>
        <source>tonnes dry matter per hectare</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1945"/>
        <source>Percent of residues left
in field after harvest:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1947"/>
        <source>% of total above-ground residues</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1950"/>
        <source>Will removed crop
residues be burned?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1952"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:14pt; font-weight:600;&quot;&gt;Tree Management&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1957"/>
        <source>Tree planted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1960"/>
        <source>default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1962"/>
        <source>Other tree</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1963"/>
        <source>How to enter advanced tree
data (to come in v2)?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1969"/>
        <source>What is the stocking
density of planted trees?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1971"/>
        <source>per hectare</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1972"/>
        <source>When were these trees planted?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1973"/>
        <source>year</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1974"/>
        <source>Will the trees affect crop yield?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1977"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:14pt; font-weight:600;&quot;&gt;Tree Thinning&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1982"/>
        <source>When will biomass be harvested,
thinned, or lopped?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1988"/>
        <source>Please enter a list and/or range
of years in which thinning occurs
(e.g. 2,7-9,18):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1991"/>
        <source>What percentage of trees are
thinned when thinning occurs?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="1994"/>
        <source>Of the thinned biomass,
how much of the following
will be left in the field:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="2012"/>
        <source>        Stems</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="2013"/>
        <source>% of thinned stem mass</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="2014"/>
        <source>        Branches</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="2015"/>
        <source>% of thinned branch mass</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="2001"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:14pt; font-weight:600;&quot;&gt;Tree Mortality&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="2006"/>
        <source>What percentage of
trees die every year?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="2009"/>
        <source>Of the dead biomass,
how much of the following
will be left in the field:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="2016"/>
        <source>How would you like to
enter growth data?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="2022"/>
        <source>Which allometric to use?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="2024"/>
        <source>--General tropical--</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="2025"/>
        <source>Ryan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="2026"/>
        <source>Chave dry</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="2027"/>
        <source>Chave moist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="2028"/>
        <source>Chave wet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="2029"/>
        <source>--Tumwebaze agroforestry trees--</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="2030"/>
        <source>Grevillea</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="2031"/>
        <source>Maesopsis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="2032"/>
        <source>Markhamia</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="2034"/>
        <source>Other allometric</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="2035"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:14pt; font-weight:600;&quot;&gt;Tree Growth&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="2040"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:14pt; font-weight:600;&quot;&gt;External Organic Inputs&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="2045"/>
        <source>When will organic inputs (EOIs)
such as litter, mulch or manure
be added to the field?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="2048"/>
        <source>List and/or range of years in which
EOIs are added (e.g. 2,7-9,18):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="2050"/>
        <source>Mass of added EOIs:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="2056"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:14pt; font-weight:600;&quot;&gt;Synthetic Fertiliser Inputs&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="2061"/>
        <source>When will synthetic fertiliser
be added to the field?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="2063"/>
        <source>List and/or range of years in which
fertiliser is added (e.g. 2,7-9,18):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="2065"/>
        <source>Mass of added fertiliser:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="2066"/>
        <source>tonnes per hectare</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="2071"/>
        <source>Nitrogen content of added fertiliser:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="2072"/>
        <source>% Nitrogen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="2073"/>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="project_dialog_ui.py" line="2074"/>
        <source>Next</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
