<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="fr">
<context>
    <name>general</name>
    <message>
        <location filename="general_dialog_ui.py" line="558"/>
        <source>General Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="general_dialog_ui.py" line="559"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:18pt; font-weight:600;&quot;&gt;GENERAL INFORMATION&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="general_dialog_ui.py" line="564"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:14pt;&quot;&gt;The following screens will prompt you to enter general and&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:14pt;&quot;&gt;geographical information about the new project&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="general_dialog_ui.py" line="570"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:14pt; font-weight:600;&quot;&gt;Project Overview&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="general_dialog_ui.py" line="575"/>
        <source>Project Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="general_dialog_ui.py" line="576"/>
        <source>Technical Specification Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="general_dialog_ui.py" line="577"/>
        <source>Type of Project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="general_dialog_ui.py" line="578"/>
        <source>Single Farm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="general_dialog_ui.py" line="579"/>
        <source>Many Farms</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="general_dialog_ui.py" line="580"/>
        <source>Regional Average</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="general_dialog_ui.py" line="581"/>
        <source>Name of farmer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="general_dialog_ui.py" line="582"/>
        <source>Project Description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="general_dialog_ui.py" line="583"/>
        <source>Location  of Project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="general_dialog_ui.py" line="584"/>
        <source>latitude</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="general_dialog_ui.py" line="585"/>
        <source>longitude</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="general_dialog_ui.py" line="586"/>
        <source>How long to run the model</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="general_dialog_ui.py" line="590"/>
        <source>years</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="general_dialog_ui.py" line="588"/>
        <source>Length of mitigation
accounting period</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="general_dialog_ui.py" line="591"/>
        <source>How would you like
the output displayed?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="general_dialog_ui.py" line="593"/>
        <source>Literate/numerate graph</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="general_dialog_ui.py" line="594"/>
        <source>Pictoral/non-literate graph</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="general_dialog_ui.py" line="595"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:14pt; font-weight:600;&quot;&gt;General Parameters&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="general_dialog_ui.py" line="600"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:14pt; font-weight:600;&quot;&gt;Climate Data&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="general_dialog_ui.py" line="605"/>
        <source>How would you like
to enter climate data?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="general_dialog_ui.py" line="607"/>
        <source>Use CRU-TS data for this
location (recommended)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="general_dialog_ui.py" line="609"/>
        <source>Load data from an existing file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="general_dialog_ui.py" line="610"/>
        <source>Enter custom data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="general_dialog_ui.py" line="611"/>
        <source>Select a file to load:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="general_dialog_ui.py" line="612"/>
        <source>Browse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="general_dialog_ui.py" line="613"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:14pt; font-weight:600;&quot;&gt;Custom Climate Data&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="general_dialog_ui.py" line="618"/>
        <source>Which are you entering?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="general_dialog_ui.py" line="619"/>
        <source>Open-pan Evaporation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="general_dialog_ui.py" line="620"/>
        <source>Evapotranspiration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="general_dialog_ui.py" line="621"/>
        <source>January</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="general_dialog_ui.py" line="622"/>
        <source>February</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="general_dialog_ui.py" line="623"/>
        <source>March</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="general_dialog_ui.py" line="624"/>
        <source>April</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="general_dialog_ui.py" line="625"/>
        <source>May</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="general_dialog_ui.py" line="626"/>
        <source>June</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="general_dialog_ui.py" line="627"/>
        <source>July</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="general_dialog_ui.py" line="628"/>
        <source>August</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="general_dialog_ui.py" line="629"/>
        <source>September</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="general_dialog_ui.py" line="630"/>
        <source>October</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="general_dialog_ui.py" line="631"/>
        <source>November</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="general_dialog_ui.py" line="632"/>
        <source>December</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="general_dialog_ui.py" line="633"/>
        <source>Temperature (C)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="general_dialog_ui.py" line="634"/>
        <source>Precipitation (mm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="general_dialog_ui.py" line="635"/>
        <source>Open-pan Evaporation (mm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="general_dialog_ui.py" line="636"/>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="general_dialog_ui.py" line="637"/>
        <source>Next</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
