<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="fr">
<context>
    <name>name</name>
    <message>
        <location filename="name_dialog_ui.py" line="41"/>
        <source>Baseline/Intervention name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="name_dialog_ui.py" line="42"/>
        <source>Enter a name for the new baseline/intervention</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
