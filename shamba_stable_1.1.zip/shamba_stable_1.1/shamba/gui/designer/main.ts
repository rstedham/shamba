<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="fr">
<context>
    <name>SHAMBA</name>
    <message>
        <location filename="main_ui.py" line="415"/>
        <source>SHAMBA</source>
        <translation></translation>
    </message>
    <message>
        <location filename="main_ui.py" line="416"/>
        <source>Enter general project information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_ui.py" line="465"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="main_ui.py" line="422"/>
        <source>General</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_ui.py" line="423"/>
        <source>Baselines created:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_ui.py" line="472"/>
        <source>&lt;No baselines created&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_ui.py" line="425"/>
        <source>Add new baseline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_ui.py" line="446"/>
        <source>Baselines</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_ui.py" line="447"/>
        <source>Interventions created:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_ui.py" line="474"/>
        <source>&lt;No interventions created&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_ui.py" line="449"/>
        <source>Add new intervention</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_ui.py" line="470"/>
        <source>Interventions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_ui.py" line="471"/>
        <source>Select a baseline to plot:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_ui.py" line="473"/>
        <source>Select an intervention to plot:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_ui.py" line="475"/>
        <source>Plot mitigation estimates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_ui.py" line="476"/>
        <source>Mitigation Estimates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_ui.py" line="477"/>
        <source>File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_ui.py" line="478"/>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_ui.py" line="479"/>
        <source>Ctrl+O</source>
        <translation></translation>
    </message>
    <message>
        <location filename="main_ui.py" line="480"/>
        <source>New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_ui.py" line="481"/>
        <source>Ctrl+N</source>
        <translation></translation>
    </message>
    <message>
        <location filename="main_ui.py" line="482"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_ui.py" line="483"/>
        <source>Ctrl+S</source>
        <translation></translation>
    </message>
    <message>
        <location filename="main_ui.py" line="484"/>
        <source>Save As...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
